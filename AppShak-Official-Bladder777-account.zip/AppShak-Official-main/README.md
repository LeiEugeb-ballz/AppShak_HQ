﻿# App-Shak Roundtable

An interactive multi-agent debate arena with a near-VR round table, scenario lobby, and real model routing (local + paid APIs).

## What You Get
- Scenario lobby with 2-5 agent selection
- 3D round table scene (React Three Fiber)
- Multi-agent orchestration server
- Local models via Ollama (beta)
- Optional providers configured via server env vars (models are backend-only)
- Discussion mode selector (Roundtable vs Debate)
- Orchestrator executive summary after each prompt
- Theme/scene selector (Neon Lab + Warm Dossier)

## Quick Start
1. Install dependencies:
   - `npm install`
2. (Optional) configure `.env`:
   - Copy `.env.example` to `.env` and fill keys if desired.
3. Run dev servers (API + client):
   - `npm run dev:all`

The app will be available at `http://localhost:5173`.

## Notes
- For free local models, install Ollama and pull at least one model (beta support).
- Use "Model Control" to map agents to models and providers. Defaults now point to OpenRouter free.
- Debate mode runs 2-4 rounds with structured rebuttals; roundtable can run as low as 1.
