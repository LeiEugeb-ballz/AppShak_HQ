const toGeminiContents = messages => {
  const contents = [];
  let systemText = '';

  messages.forEach(msg => {
    if (msg.role === 'system') {
      systemText += (systemText ? '\n' : '') + msg.content;
    } else {
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      });
    }
  });

  return { contents, systemText };
};

export const geminiChat = async ({ baseUrl, apiKey, model, messages, temperature }) => {
  if (!apiKey) throw new Error('Gemini API key missing');
  if (!model) throw new Error('Gemini model missing');

  const { contents, systemText } = toGeminiContents(messages);
  const url = `${baseUrl}/models/${model}:generateContent?key=${apiKey}`;
  const body = {
    contents,
    generationConfig: { temperature: temperature ?? 0.7 }
  };
  if (systemText) {
    body.systemInstruction = { parts: [{ text: systemText }] };
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Gemini request failed');
  }

  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.map(p => p.text).join('')?.trim() || '';
};
