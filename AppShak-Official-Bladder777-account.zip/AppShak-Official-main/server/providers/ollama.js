export const listOllamaModels = async host => {
  const res = await fetch(host + '/api/tags');
  if (!res.ok) throw new Error('Ollama not reachable');
  const data = await res.json();
  return (data.models || []).map(m => ({ name: m.name, model: m.name }));
};

export const ollamaChat = async ({ host, model, messages, temperature }) => {
  const res = await fetch(host + '/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      messages,
      stream: false,
      options: temperature ? { temperature } : undefined
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Ollama request failed');
  }

  const data = await res.json();
  return data.message?.content || '';
};
