export const openaiChat = async ({
  baseUrl,
  apiKey,
  model,
  messages,
  temperature,
  timeoutMs = 30000,
  extraHeaders = {}
}) => {
  if (!apiKey) throw new Error('OpenAI API key missing');
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(baseUrl + '/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + apiKey,
        ...extraHeaders
      },
      body: JSON.stringify({
        model,
        messages,
        temperature: temperature ?? 0.7
      }),
      signal: controller.signal
    });
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new Error('OpenAI request timeout after ' + timeoutMs + 'ms');
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    let message = 'OpenAI request failed';
    if (text) {
      try {
        const parsed = JSON.parse(text);
        message = parsed.error?.message || parsed.message || text;
      } catch {
        message = text;
      }
    }
    throw new Error(message + ' (status ' + res.status + ')');
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim() || '';
};
