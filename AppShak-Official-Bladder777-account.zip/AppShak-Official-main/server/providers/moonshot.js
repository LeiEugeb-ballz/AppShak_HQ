export const moonshotChat = async ({ baseUrl, apiKey, model, messages, temperature }) => {
  if (!apiKey) throw new Error('Moonshot API key missing');
  if (!model) throw new Error('Moonshot model missing');

  const res = await fetch(baseUrl + '/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + apiKey
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: temperature ?? 0.7
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Moonshot request failed');
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim() || '';
};
