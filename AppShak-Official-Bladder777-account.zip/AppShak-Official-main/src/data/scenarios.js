export const scenarios = [
  {
    id: 'war-room',
    title: 'Product War Room',
    vibe: 'High-stakes launch. Decisions in hours, not weeks.',
    description: 'Align stakeholders, resolve blockers, and ship a crisp plan for launch readiness.',
    prompt:
      'You are in a product war room. Prioritize risks, resolve conflicts, and converge on a launch plan with clear owners and timelines.'
  },
  {
    id: 'hardware-lab',
    title: 'Hardware Lab',
    vibe: 'ESP32 eyes, latency, and deterministic control.',
    description: 'Diagnose the hardware stack and propose a path to stable 30 FPS dual displays.',
    prompt:
      'You are in a hardware lab. Diagnose root causes, propose tests, and deliver a plan for stable, deterministic performance.'
  },
  {
    id: 'brand-vision',
    title: 'Brand Vision Council',
    vibe: 'Storytelling, positioning, and market fit.',
    description: 'Sharpen the narrative, differentiation, and go-to-market language.',
    prompt:
      'You are in a brand vision council. Refine positioning, articulate differentiation, and craft a bold narrative.'
  },
  {
    id: 'crisis-response',
    title: 'Incident Response',
    vibe: 'Live outage, transparency, speed, and trust.',
    description: 'Coordinate response, root cause analysis, and customer comms.',
    prompt:
      'You are in an incident response meeting. Stabilize the system, identify root cause, and craft transparent communications.'
  },
  {
    id: 'investor-brief',
    title: 'Investor Brief',
    vibe: 'Metrics, defensibility, and crisp vision.',
    description: 'Prepare a decisive, numbers-driven narrative for investors.',
    prompt:
      'You are in an investor briefing. Provide metrics-driven clarity, defensibility, and a compelling roadmap.'
  }
];