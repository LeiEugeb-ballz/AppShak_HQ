import React, { useMemo, useState, useEffect, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import { agents as defaultAgents } from './data/agents';
import { scenarios } from './data/scenarios';

const STORAGE_KEYS = {
  auth: 'appshak_auth',
  mapping: 'appshak_model_mapping',
  theme: 'appshak_theme',
  mode: 'appshak_mode',
  providers: 'appshak_providers'
};

const apiFetch = async (path, options = {}, authToken, timeoutMs = 35000) => {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };
  if (authToken) headers['Authorization'] = 'Bearer ' + authToken;

  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(path, { ...options, headers, signal: controller.signal });
  } catch (error) {
    if (error.name === 'AbortError') {
      const err = new Error('Request timed out. Please try again.');
      err.status = 408;
      throw err;
    }
    throw error;
  } finally {
    clearTimeout(id);
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const err = new Error(body.error || 'Request failed: ' + res.status);
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return res.json();
};

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error) {
    console.error('UI error boundary', error);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="boot-error">
          <div className="boot-error-card">
            <h3>App failed to load</h3>
            <div className="muted">{this.state.error.message || 'Unknown UI error'}</div>
            <button
              className="primary"
              onClick={() => {
                localStorage.clear();
                window.location.reload();
              }}
            >
              Reset & Reload
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const themes = [
  {
    id: 'lab',
    name: 'Neon Lab',
    description: 'High-contrast, tech-forward, holographic feel.'
  },
  {
    id: 'dossier',
    name: 'Warm Dossier',
    description: 'Editorial warmth with soft neutrals and clarity.'
  }
];

const saveLocal = (key, value) => {
  localStorage.setItem(key, JSON.stringify(value));
};

const readLocal = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
};

const AgentOrb = ({ agent, index, total, active }) => {
  const groupRef = useRef(null);
  const radius = 5.2;
  const angle = (index / total) * Math.PI * 2;
  const x = Math.cos(angle) * radius;
  const z = Math.sin(angle) * radius;
  const seed = index * 0.4;

  useFrame(({ clock }) => {
    if (!groupRef.current) return;
    const t = clock.getElapsedTime();
    groupRef.current.position.y = Math.sin(t + seed) * 0.12;
    groupRef.current.rotation.y = t * 0.12;
  });

  return (
    <group ref={groupRef} position={[x, 0, z]}>
      <mesh>
        <sphereGeometry args={[0.55, 32, 32]} />
        <meshStandardMaterial
          color={agent.color}
          emissive={agent.color}
          emissiveIntensity={active ? 1 : 0.5}
          roughness={0.2}
          metalness={0.6}
        />
      </mesh>
      <mesh position={[0, -0.7, 0]}>
        <cylinderGeometry args={[0.5, 0.6, 0.25, 32]} />
        <meshStandardMaterial color="#0b0f1b" roughness={0.6} metalness={0.5} />
      </mesh>
      <Html position={[0, 0.9, 0]} center>
        <div className={'agent-label ' + (active ? 'active' : '')}>
          <span className="agent-icon">{agent.icon}</span>
          <span>{agent.name}</span>
        </div>
      </Html>
    </group>
  );
};

const Scene = ({ agents, activeAgentId }) => {
  return (
    <Canvas camera={{ position: [0, 4.5, 9], fov: 50 }}>
      <color attach="background" args={['#05070f']} />
      <fog attach="fog" args={['#05070f', 10, 25]} />
      <ambientLight intensity={0.7} />
      <directionalLight position={[5, 8, 5]} intensity={1.1} />
      <pointLight position={[-5, 3, -6]} intensity={1.4} color="#00d4ff" />
      <pointLight position={[4, 2, 6]} intensity={0.8} color="#ff006e" />

      <mesh position={[0, -1.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[8, 64]} />
        <meshStandardMaterial color="#0e111c" roughness={0.85} metalness={0.2} />
      </mesh>

      <mesh position={[0, -0.6, 0]}>
        <cylinderGeometry args={[3.2, 3.4, 0.6, 64]} />
        <meshStandardMaterial color="#111827" roughness={0.5} metalness={0.5} />
      </mesh>

      <mesh position={[0, -0.2, 0]}>
        <cylinderGeometry args={[2.6, 2.8, 0.4, 64]} />
        <meshStandardMaterial color="#0f172a" roughness={0.35} metalness={0.6} />
      </mesh>

      {agents.map((agent, index) => (
        <AgentOrb
          key={agent.id}
          agent={agent}
          index={index}
          total={agents.length}
          active={agent.id === activeAgentId}
        />
      ))}

      <OrbitControls enableZoom={false} maxPolarAngle={Math.PI / 2.1} minPolarAngle={Math.PI / 4} />
    </Canvas>
  );
};

const Login = ({ onLogin, busy, error }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  return (
    <div className="panel login">
      <h1>App-Shak Roundtable</h1>
      <p className="muted">Secure access to the agent council. Local auth first, enterprise-ready later.</p>
      <div className="field">
        <label>Username</label>
        <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Commander" />
      </div>
      <div className="field">
        <label>Password</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Optional" />
      </div>
      <button className="primary" onClick={() => onLogin(username, password)} disabled={busy}>
        {busy ? 'Authenticating...' : 'Enter the Lab'}
      </button>
      {error ? <div className="error">{error}</div> : null}
      <div className="login-foot">Tip: Set `APP_SHAK_ADMIN_PASSWORD` in `.env` for gated access.</div>
    </div>
  );
};

const Lobby = ({
  scenarios,
  selectedScenarioId,
  onSelectScenario,
  onEnterRoom,
  activeAgents,
  setActiveAgents,
  agentsAll,
  modelMapping,
  setModelMapping,
  providerConfig,
  setProviderConfig,
  openrouterModels,
  openrouterStatus,
  onLoadOpenRouterModels,
  openrouterFilter,
  setOpenrouterFilter,
  ollamaModels,
  mode,
  setMode,
  realismMode,
  setRealismMode,
  rounds,
  setRounds,
  freelance,
  setFreelance,
  onBookFreelance,
  freelanceBooked
}) => {
  const toggleAgent = id => {
    if (activeAgents.includes(id)) {
      if (activeAgents.length <= 2) return;
      setActiveAgents(activeAgents.filter(a => a !== id));
      return;
    }
    if (activeAgents.length >= 5) return;
    setActiveAgents(activeAgents.concat(id));
  };

  const providerOptions = [
    { value: 'openrouter', label: 'OpenRouter' },
    { value: 'ollama', label: 'Ollama (beta)' },
    { value: 'openai', label: 'OpenAI' },
    { value: 'anthropic', label: 'Anthropic' },
    { value: 'gemini', label: 'Gemini' },
    { value: 'moonshot', label: 'Moonshot' }
  ];

  const getAgentDefault = id => agentsAll.find(agent => agent.id === id)?.defaultModel || {};

  const updateMapping = (agentId, patch) => {
    setModelMapping(prev => ({
      ...prev,
      [agentId]: {
        ...getAgentDefault(agentId),
        ...(prev[agentId] || {}),
        ...patch
      }
    }));
  };

  const getDefaultModelForProvider = provider => {
    if (provider === 'openrouter') return openrouterSelectModels[0]?.id || 'openrouter/free';
    if (provider === 'ollama') return ollamaModels[0]?.model || '';
    return '';
  };

  const openrouterSelectModels = [
    { id: 'openrouter/free', name: 'OpenRouter Free' },
    { id: 'openrouter/auto', name: 'Auto Router' },
    ...openrouterModels
  ];

  return (
    <div className="lobby">
      <div className="lobby-header">
        <div>
          <h2>Scenario Lobby</h2>
          <p className="muted">Pick a table, invite 2-5 agents, and drop into the debate.</p>
        </div>
        <button className="primary" onClick={onEnterRoom}>
          Take a Seat
        </button>
      </div>
      {freelanceBooked ? (
        <div className="booking-banner">
          Freelance session requested for {freelanceBooked.date} at {freelanceBooked.time} (
          {freelanceBooked.roomType}). We will call you back to confirm.
        </div>
      ) : null}
      <div className="mode-panel">
        <div>
          <h3>Discussion Mode</h3>
          <p className="muted">Switch between collaborative roundtable and structured debate.</p>
        </div>
        <div className="mode-controls">
          <button
            className={mode === 'roundtable' ? 'primary' : ''}
            onClick={() => setMode('roundtable')}
          >
            Roundtable
          </button>
          <button className={mode === 'debate' ? 'primary' : ''} onClick={() => setMode('debate')}>
            Debate
          </button>
          <div className="rounds">
            <label>Rounds</label>
            <input
              type="range"
              min="1"
              max="4"
              value={rounds}
              onChange={e => setRounds(Number(e.target.value))}
            />
            <span>{rounds}</span>
          </div>
        </div>
      </div>
      <div className="mode-panel">
        <div>
          <h3>Realism Mode</h3>
          <p className="muted">Let the chair guide flow without hard time cuts.</p>
        </div>
        <div className="mode-controls">
          <button
            className={realismMode === 'static' ? 'primary' : ''}
            onClick={() => setRealismMode('static')}
          >
            Static
          </button>
          <button
            className={realismMode === 'dynamic' ? 'primary' : ''}
            onClick={() => setRealismMode('dynamic')}
          >
            Dynamic
          </button>
          <button
            className={realismMode === 'adaptive' ? 'primary' : ''}
            onClick={() => setRealismMode('adaptive')}
          >
            Adaptive
          </button>
        </div>
      </div>
      <div className="model-router">
        <div className="model-router-header">
          <div>
            <h3>Model Router</h3>
            <p className="muted">Bring OpenRouter and local models into the roundtable.</p>
          </div>
          <div className="model-router-actions">
            <button className="ghost" onClick={() => setModelMapping(defaultMapping)}>
              Reset mappings
            </button>
          </div>
        </div>
        <div className="model-router-grid">
          <div className="field">
            <label>OpenRouter API Key</label>
            <input
              type="password"
              placeholder="sk-or-..."
              value={providerConfig.openrouterKey}
              onChange={e => setProviderConfig({ ...providerConfig, openrouterKey: e.target.value })}
            />
          </div>
          <div className="field">
            <label>OpenRouter Base URL</label>
            <input
              value={providerConfig.openrouterBaseUrl}
              onChange={e => setProviderConfig({ ...providerConfig, openrouterBaseUrl: e.target.value })}
              placeholder="https://openrouter.ai/api/v1"
            />
          </div>
          <div className="field">
            <label>OpenRouter App Name</label>
            <input
              value={providerConfig.openrouterAppName}
              onChange={e => setProviderConfig({ ...providerConfig, openrouterAppName: e.target.value })}
              placeholder="App-Shak Roundtable"
            />
          </div>
          <div className="field">
            <label>OpenRouter App URL</label>
            <input
              value={providerConfig.openrouterAppUrl}
              onChange={e => setProviderConfig({ ...providerConfig, openrouterAppUrl: e.target.value })}
              placeholder="https://yourdomain.com"
            />
          </div>
        </div>
        <div className="model-router-actions">
          <button className="primary" onClick={onLoadOpenRouterModels} disabled={!providerConfig.openrouterKey}>
            Load OpenRouter Models
          </button>
          <span className={'status ' + openrouterStatus.type}>{openrouterStatus.message}</span>
        </div>
        <div className="model-router-filter">
          <input
            placeholder="Filter OpenRouter models..."
            value={openrouterFilter}
            onChange={e => setOpenrouterFilter(e.target.value)}
          />
          <span className="muted">{openrouterModels.length} models cached</span>
        </div>
        <div className="model-mapping">
          {agentsAll.map(agent => {
            const mapping = modelMapping[agent.id] || getAgentDefault(agent.id);
            const provider = mapping?.provider || 'openrouter';
            const modelValue = mapping?.model || '';
            const filteredOpenRouter = openrouterFilter
              ? openrouterSelectModels.filter(model =>
                  model.name.toLowerCase().includes(openrouterFilter.toLowerCase()) ||
                  model.id.toLowerCase().includes(openrouterFilter.toLowerCase())
                )
              : openrouterSelectModels;

            return (
              <div key={agent.id} className="mapping-row">
                <div className="mapping-title">
                  <span style={{ color: agent.color }}>{agent.icon}</span>
                  {agent.name}
                </div>
                <select
                  value={provider}
                  onChange={e => {
                    const nextProvider = e.target.value;
                    updateMapping(agent.id, {
                      provider: nextProvider,
                      model: getDefaultModelForProvider(nextProvider)
                    });
                  }}
                >
                  {providerOptions.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                {provider === 'openrouter' ? (
                  <select
                    value={modelValue}
                    onChange={e => updateMapping(agent.id, { model: e.target.value })}
                  >
                    {filteredOpenRouter.map(model => (
                      <option key={model.id} value={model.id}>
                        {model.name || model.id}
                      </option>
                    ))}
                  </select>
                ) : null}
                {provider === 'ollama' ? (
                  <select
                    value={modelValue}
                    onChange={e => updateMapping(agent.id, { model: e.target.value })}
                  >
                    {(ollamaModels.length ? ollamaModels : [{ name: 'No models found', model: '' }]).map(model => (
                      <option key={model.model || model.name} value={model.model || ''}>
                        {model.name}
                      </option>
                    ))}
                  </select>
                ) : null}
                {provider !== 'openrouter' && provider !== 'ollama' ? (
                  <input
                    value={modelValue}
                    onChange={e => updateMapping(agent.id, { model: e.target.value })}
                    placeholder="Model ID"
                  />
                ) : null}
              </div>
            );
          })}
        </div>
      </div>
      <div className="scenario-grid">
        {scenarios.map(scene => (
          <button
            key={scene.id}
            className={'scenario-card ' + (selectedScenarioId === scene.id ? 'selected' : '')}
            onClick={() => onSelectScenario(scene.id)}
          >
            <div className="scenario-title">{scene.title}</div>
            <div className="scenario-vibe">{scene.vibe}</div>
            <div className="scenario-desc">{scene.description}</div>
          </button>
        ))}
      </div>
      <div className="agent-select">
        <div className="agent-select-header">
          <h3>Invite Agents</h3>
          <span className="muted">{activeAgents.length} / 5 selected</span>
        </div>
        <div className="agent-grid">
          {defaultAgents.map(agent => (
            <button
              key={agent.id}
              className={'agent-card ' + (activeAgents.includes(agent.id) ? 'selected' : '')}
              onClick={() => toggleAgent(agent.id)}
            >
              <div className="agent-icon" style={{ background: agent.color + '22', color: agent.color }}>
                {agent.icon}
              </div>
              <div>
                <div className="agent-name">{agent.name}</div>
                <div className="agent-role">{agent.role}</div>
              </div>
            </button>
          ))}
        </div>
        <div className="muted note">Choose 2-5 agents. Atlas + Scout + Artisan is a solid baseline.</div>
        <div className="muted note">Shortcut: Shift + 1..5 to toggle agents in order.</div>
      </div>
      <div className="mode-panel">
        <div>
          <h3>Freelance Session</h3>
          <p className="muted">
            Book a session. This schedules a callback instead of starting immediately.
          </p>
        </div>
        <div className="mode-controls">
          <button
            className={freelance.enabled ? 'primary' : ''}
            onClick={() => setFreelance({ ...freelance, enabled: !freelance.enabled })}
          >
            {freelance.enabled ? 'Enabled' : 'Disabled'}
          </button>
          <button className="ghost" onClick={onBookFreelance} disabled={!freelance.enabled}>
            Request Booking
          </button>
        </div>
      </div>
      {freelance.enabled ? (
        <div className="freelance-grid">
          <div className="field">
            <label>Date</label>
            <input
              type="date"
              value={freelance.date}
              onChange={e => setFreelance({ ...freelance, date: e.target.value })}
            />
          </div>
          <div className="field">
            <label>Time</label>
            <input
              type="time"
              value={freelance.time}
              onChange={e => setFreelance({ ...freelance, time: e.target.value })}
            />
          </div>
          <div className="field">
            <label>Room Type</label>
            <select
              value={freelance.roomType}
              onChange={e => setFreelance({ ...freelance, roomType: e.target.value })}
            >
              <option value="open">Open Room</option>
              <option value="closed">Closed (selected agents)</option>
            </select>
          </div>
          <div className="field">
            <label>Notes</label>
            <input
              value={freelance.notes}
              onChange={e => setFreelance({ ...freelance, notes: e.target.value })}
              placeholder="Topic or constraints"
            />
          </div>
        </div>
      ) : null}
    </div>
  );
};

const Message = ({ msg, agentsById }) => {
  const agent = msg.agentId ? agentsById[msg.agentId] : null;
  return (
    <div className={'message ' + msg.role}>
      <div className="message-meta">
        <span className="message-author" style={{ color: agent?.color || '#9ca3af' }}>
          {agent ? agent.icon + ' ' + agent.name : msg.role === 'user' ? 'You' : 'System'}
        </span>
        <span className="message-timestamp">{new Date(msg.timestamp).toLocaleTimeString()}</span>
      </div>
      <div className="message-body">{msg.content}</div>
    </div>
  );
};

const Room = ({
  scenario,
  agents,
  messages,
  onSend,
  activeAgentId,
  setActiveAgentId,
  busy,
  onExport,
  onSpeak,
  onReset,
  sessionEnded,
  remainingSeconds,
  pendingNotice
}) => {
  const [input, setInput] = useState('');
  const agentsById = useMemo(() => Object.fromEntries(agents.map(a => [a.id, a])), [agents]);
  const listRef = useRef(null);

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [messages, busy]);

  useEffect(() => {
    const handler = event => {
      if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;
      const index = Number(event.key);
      if (!Number.isNaN(index) && index >= 1 && index <= agents.length) {
        setActiveAgentId(agents[index - 1].id);
      }
      if (event.key.toLowerCase() === 'r' && event.ctrlKey) {
        event.preventDefault();
        onReset();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [agents, onReset, setActiveAgentId]);

  return (
    <div className="room">
      <div className="scene-panel">
        <Scene agents={agents} activeAgentId={activeAgentId} />
      </div>
      <div className="chat-panel">
        <div className="chat-header">
          <div>
            <div className="chat-title">{scenario.title}</div>
            <div className="muted">{scenario.vibe}</div>
            {sessionEnded ? <div className="session-ended">Session complete (500s cap).</div> : null}
            {!sessionEnded ? (
              <div className="session-timer">Time left: {Math.max(0, remainingSeconds)}s</div>
            ) : null}
          </div>
          <div className="agent-chips">
            <button className="ghost" onClick={onExport} title="Export transcript">
              Export
            </button>
            <button className="ghost" onClick={onSpeak} title="Play latest response">
              Audio
            </button>
            <button className="ghost" onClick={onReset} title="Reset session">
              Reset
            </button>
            {agents.map(agent => (
              <button
                key={agent.id}
                className={'chip ' + (activeAgentId === agent.id ? 'active' : '')}
                onClick={() => setActiveAgentId(agent.id)}
              >
                <span style={{ color: agent.color }}>{agent.icon}</span>
                {agent.name}
              </button>
            ))}
          </div>
        </div>
        <div className="chat-body" ref={listRef}>
          {messages.map(msg => (
            <Message key={msg.id} msg={msg} agentsById={agentsById} />
          ))}
          {busy ? <div className="thinking">Agents are deliberating...</div> : null}
          {pendingNotice ? <div className="thinking">{pendingNotice}</div> : null}
        </div>
        <div className="chat-input">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Pose a question, set constraints, or ask for debate."
            disabled={sessionEnded}
          />
          <button
            className="primary"
            onClick={() => {
              if (!input.trim() || busy) return;
              onSend(input.trim());
              setInput('');
            }}
            disabled={busy || sessionEnded}
          >
            {sessionEnded ? 'Session Closed' : 'Send to Council'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [auth, setAuth] = useState(() => readLocal(STORAGE_KEYS.auth, null));
  const defaultMapping = useMemo(
    () => Object.fromEntries(defaultAgents.map(agent => [agent.id, agent.defaultModel || {}])),
    []
  );
  const [modelMapping, setModelMapping] = useState(() => ({
    ...defaultMapping,
    ...readLocal(STORAGE_KEYS.mapping, {})
  }));
  const [providerConfig, setProviderConfig] = useState(() =>
    readLocal(STORAGE_KEYS.providers, {
      openrouterKey: '',
      openrouterBaseUrl: 'https://openrouter.ai/api/v1',
      openrouterAppName: 'App-Shak Roundtable',
      openrouterAppUrl: ''
    })
  );
  const [theme, setTheme] = useState(() => readLocal(STORAGE_KEYS.theme, 'lab'));
  const [mode, setMode] = useState(() => readLocal(STORAGE_KEYS.mode, 'roundtable'));
  const [realismMode, setRealismMode] = useState('adaptive');
  const [rounds, setRounds] = useState(3);
  const [freelance, setFreelance] = useState({
    enabled: false,
    date: '',
    time: '',
    roomType: 'open',
    notes: ''
  });
  const [freelanceBooked, setFreelanceBooked] = useState(null);
  const [stage, setStage] = useState(auth ? 'lobby' : 'login');
  const [busy, setBusy] = useState(false);
  const [pendingNotice, setPendingNotice] = useState('');
  const [error, setError] = useState('');
  const [scenarioId, setScenarioId] = useState(scenarios[0]?.id);
  const [activeAgents, setActiveAgents] = useState(['atlas', 'scout', 'artisan', 'guardian']);
  const [messages, setMessages] = useState([]);
  const [activeAgentId, setActiveAgentId] = useState('atlas');
  const [sessionId, setSessionId] = useState(null);
  const [sessionEnded, setSessionEnded] = useState(false);
  const [ollamaModels, setOllamaModels] = useState([]);
  const [openrouterModels, setOpenrouterModels] = useState([]);
  const [openrouterStatus, setOpenrouterStatus] = useState({ type: 'idle', message: 'OpenRouter idle.' });
  const [openrouterFilter, setOpenrouterFilter] = useState('');
  const [remainingSeconds, setRemainingSeconds] = useState(500);
  const [bootError, setBootError] = useState('');
  const speechRef = useRef(null);

  const scenario = scenarios.find(s => s.id === scenarioId) || scenarios[0];
  const agents = defaultAgents.filter(agent => activeAgents.includes(agent.id));

  useEffect(() => {
    const handler = event => {
      if (stage !== 'lobby') return;
      if (!event.shiftKey) return;
      const index = Number(event.key);
      if (Number.isNaN(index) || index < 1 || index > defaultAgents.length) return;
      const target = defaultAgents[index - 1].id;
      setActiveAgents(prev => {
        if (prev.includes(target)) {
          return prev.length <= 2 ? prev : prev.filter(id => id !== target);
        }
        if (prev.length >= 5) return prev;
        return prev.concat(target);
      });
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [stage]);

  useEffect(() => {
    saveLocal(STORAGE_KEYS.mapping, modelMapping);
  }, [modelMapping]);

  useEffect(() => {
    saveLocal(STORAGE_KEYS.providers, providerConfig);
  }, [providerConfig]);

  useEffect(() => {
    const onError = event => {
      const message = event?.message || 'Unknown error';
      setBootError('App error: ' + message);
    };
    const onRejection = event => {
      const message = event?.reason?.message || 'Unhandled promise rejection';
      setBootError('App error: ' + message);
    };
    window.addEventListener('error', onError);
    window.addEventListener('unhandledrejection', onRejection);
    return () => {
      window.removeEventListener('error', onError);
      window.removeEventListener('unhandledrejection', onRejection);
    };
  }, []);

  useEffect(() => {
    saveLocal(STORAGE_KEYS.theme, theme);
    document.body.classList.remove('theme-lab', 'theme-dossier');
    document.body.classList.add(theme === 'dossier' ? 'theme-dossier' : 'theme-lab');
  }, [theme]);

  useEffect(() => {
    saveLocal(STORAGE_KEYS.mode, mode);
  }, [mode]);

  useEffect(() => {
    if (auth) saveLocal(STORAGE_KEYS.auth, auth);
  }, [auth]);

  useEffect(() => {
    return () => {
      if (window?.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  useEffect(() => {
    const loadOllama = async () => {
      try {
        const data = await apiFetch('/api/ollama/models', {}, auth?.token);
        setOllamaModels(data.models || []);
      } catch {
        setOllamaModels([]);
      }
    };
    loadOllama();
  }, [auth]);

  const loadOpenRouterModels = async () => {
    if (!providerConfig.openrouterKey) {
      setOpenrouterStatus({ type: 'error', message: 'Add an OpenRouter API key first.' });
      return;
    }
    setOpenrouterStatus({ type: 'loading', message: 'Fetching OpenRouter models...' });
    try {
      const data = await apiFetch(
        '/api/openrouter/models',
        {
          headers: {
            'X-OpenRouter-Key': providerConfig.openrouterKey,
            'X-OpenRouter-BaseUrl': providerConfig.openrouterBaseUrl
          }
        },
        auth?.token
      );
      const models = data.data || [];
      setOpenrouterModels(models);
      setOpenrouterStatus({
        type: 'success',
        message: `Loaded ${models.length} models.`
      });
    } catch (err) {
      setOpenrouterStatus({ type: 'error', message: err.message || 'Failed to load models.' });
    }
  };

  const buildProviderHeaders = mapping => {
    const usesOpenRouter = Object.values(mapping || {}).some(item => item?.provider === 'openrouter');
    if (!usesOpenRouter) return {};
    const headers = {};
    if (providerConfig.openrouterBaseUrl) headers['X-OpenAI-BaseUrl'] = providerConfig.openrouterBaseUrl;
    if (providerConfig.openrouterKey) headers['X-OpenAI-Key'] = providerConfig.openrouterKey;
    if (providerConfig.openrouterAppUrl) headers['X-OpenRouter-App-Url'] = providerConfig.openrouterAppUrl;
    if (providerConfig.openrouterAppName) headers['X-OpenRouter-App-Name'] = providerConfig.openrouterAppName;
    return headers;
  };

  const handleLogin = async (username, password) => {
    setBusy(true);
    setError('');
    try {
      const data = await apiFetch(
        '/api/auth/login',
        {
          method: 'POST',
          body: JSON.stringify({ username, password })
        },
        null
      );
      setAuth(data);
      setStage('lobby');
    } catch (err) {
      setError(err.message || 'Login failed');
    } finally {
      setBusy(false);
    }
  };

  const handleUnauthorized = () => {
    setAuth(null);
    setStage('login');
    setMessages([]);
    setSessionId(null);
    setError('Session expired. Please log in again.');
  };

  const enterRoom = async () => {
    setBusy(true);
    setError('');
    try {
      const providerHeaders = buildProviderHeaders(modelMapping);
      const data = await apiFetch(
        '/api/session/start',
        {
          method: 'POST',
          body: JSON.stringify({
            scenarioId,
            agents: activeAgents,
            modelMapping,
            mode,
            rounds,
            realismMode
          }),
          headers: providerHeaders
        },
        auth?.token
      );
      setSessionId(data.sessionId);
      setSessionEnded(false);
      setMessages([
        {
          id: 'sys-' + Date.now(),
          role: 'system',
          content: 'Session started: ' + scenario.title + '. Agents are seated.',
          timestamp: Date.now()
        }
      ]);
      setStage('room');
    } catch (err) {
      if (err.status === 401) {
        handleUnauthorized();
        return;
      }
      setError(err.message || 'Could not start session');
    } finally {
      setBusy(false);
    }
  };

  const sendMessage = async text => {
    if (!sessionId) return;
    if (sessionEnded) return;
    const userMsg = {
      id: 'user-' + Date.now(),
      role: 'user',
      content: text,
      timestamp: Date.now()
    };
    setMessages(prev => prev.concat(userMsg));
    setBusy(true);
    setError('');
    setPendingNotice('Working...');

    try {
      const providerHeaders = buildProviderHeaders(modelMapping);
      const data = await apiFetch(
        '/api/session/step',
        {
          method: 'POST',
          body: JSON.stringify({
            sessionId,
            message: text,
            history: messages.concat(userMsg),
            modelMapping,
            mode,
            rounds,
            realismMode
          }),
          headers: providerHeaders
        },
        auth?.token
      );
      if (typeof data.remainingSeconds === 'number') {
        setRemainingSeconds(data.remainingSeconds);
      }
      if (data.ended) {
        setSessionEnded(true);
        setMessages(prev =>
          prev.concat({
            id: 'end-' + Date.now(),
            role: 'system',
            content: data.notice || 'Session has concluded.',
            timestamp: Date.now()
          })
        );
        return;
      }
      const next = data.responses.map(res => ({
        id: res.agentId + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7),
        role: 'agent',
        agentId: res.agentId,
        content: res.content,
        timestamp: Date.now()
      }));
      const summary = data.summary
        ? [
            {
              id: 'summary-' + Date.now(),
              role: 'system',
              content: data.summary,
              timestamp: Date.now()
            }
          ]
        : [];
      setMessages(prev => prev.concat(next).concat(summary));
    } catch (err) {
      if (err.status === 401) {
        handleUnauthorized();
        return;
      }
      setMessages(prev =>
        prev.concat({
          id: 'err-' + Date.now(),
          role: 'system',
          content: err.message || 'Agent response failed.',
          timestamp: Date.now()
        })
      );
    } finally {
      setBusy(false);
      setPendingNotice('');
    }
  };

  const bookFreelance = () => {
    if (!freelance.enabled) return;
    if (!freelance.date || !freelance.time) {
      setError('Please select a date and time for the freelance booking.');
      return;
    }
    setFreelanceBooked({
      date: freelance.date,
      time: freelance.time,
      roomType: freelance.roomType
    });
  };

  const resetSession = () => {
    setMessages([]);
    setSessionId(null);
    setStage('lobby');
    setSessionEnded(false);
    setRemainingSeconds(500);
  };

  const speakText = text => {
    if (!text) return;
    if (!window?.speechSynthesis) {
      setError('Browser text-to-speech not available.');
      return;
    }
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'en-US';
    utter.rate = 1;
    utter.pitch = 1;
    speechRef.current = utter;
    window.speechSynthesis.speak(utter);
  };

  const speakLatest = () => {
    const latest = [...messages]
      .slice()
      .reverse()
      .find(msg => msg.role === 'agent' || msg.role === 'system');
    speakText(latest?.content || 'No agent output yet.');
  };

  const exportTranscript = () => {
    if (!messages.length) return;
    const rows = messages.map(msg => ({
      time: new Date(msg.timestamp).toISOString(),
      role: msg.role,
      agent: msg.agentId || '',
      content: msg.content
    }));
    const markdown = rows
      .map(row => `- **${row.role}** ${row.agent ? `(${row.agent})` : ''} ${row.time}\n  ${row.content}`)
      .join('\n');
    const payload = {
      scenario: scenario.title,
      mode,
      rounds,
      messages: rows
    };
    const blob = new Blob([markdown + '\n\n```json\n' + JSON.stringify(payload, null, 2) + '\n```\n'], {
      type: 'text/markdown'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'appshak-transcript.md';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <ErrorBoundary>
      <div className="app-shell">
        {bootError ? (
          <div className="boot-error">
            <div className="boot-error-card">
              <h3>App failed to load</h3>
              <div className="muted">{bootError}</div>
              <button
                className="primary"
                onClick={() => {
                  localStorage.clear();
                  window.location.reload();
                }}
              >
                Reset & Reload
              </button>
            </div>
          </div>
        ) : null}
        <header className="topbar">
        <div className="brand">
          <div className="brand-mark">AS</div>
          <div>
            <div className="brand-title">App-Shak Roundtable</div>
            <div className="brand-sub">Orchestrated multi-agent debate arena</div>
          </div>
        </div>
        <div className="topbar-actions">
          <div className="theme-select">
            <label>Scene</label>
            <select value={theme} onChange={e => setTheme(e.target.value)}>
              {themes.map(option => (
                <option key={option.id} value={option.id}>
                  {option.name}
                </option>
              ))}
            </select>
          </div>
          {stage !== 'login' ? (
            <>
              <button
                className="ghost"
                onClick={() => {
                  setStage('lobby');
                  setSessionId(null);
                  setMessages([]);
                }}
              >
                Lobby
              </button>
            </>
          ) : null}
        </div>
      </header>

      <main className="main">
        {stage === 'login' && <Login onLogin={handleLogin} busy={busy} error={error} />}
        {stage === 'lobby' && (
          <Lobby
            scenarios={scenarios}
            selectedScenarioId={scenarioId}
            onSelectScenario={setScenarioId}
            onEnterRoom={enterRoom}
            activeAgents={activeAgents}
            setActiveAgents={setActiveAgents}
            agentsAll={defaultAgents}
            modelMapping={modelMapping}
            setModelMapping={setModelMapping}
            providerConfig={providerConfig}
            setProviderConfig={setProviderConfig}
            openrouterModels={openrouterModels}
            openrouterStatus={openrouterStatus}
            onLoadOpenRouterModels={loadOpenRouterModels}
            openrouterFilter={openrouterFilter}
            setOpenrouterFilter={setOpenrouterFilter}
            ollamaModels={ollamaModels}
            mode={mode}
            setMode={setMode}
            realismMode={realismMode}
            setRealismMode={setRealismMode}
            rounds={rounds}
            setRounds={setRounds}
            freelance={freelance}
            setFreelance={setFreelance}
            onBookFreelance={bookFreelance}
            freelanceBooked={freelanceBooked}
          />
        )}
        {stage === 'room' && (
          <Room
            scenario={scenario}
            agents={agents}
            messages={messages}
            onSend={sendMessage}
            activeAgentId={activeAgentId}
            setActiveAgentId={setActiveAgentId}
            busy={busy}
            onExport={exportTranscript}
            onSpeak={speakLatest}
            onReset={resetSession}
            sessionEnded={sessionEnded}
            remainingSeconds={remainingSeconds}
            pendingNotice={pendingNotice}
          />
        )}
        {error && stage !== 'login' ? <div className="toast error">{error}</div> : null}
        </main>

      </div>
    </ErrorBoundary>
  );
}
