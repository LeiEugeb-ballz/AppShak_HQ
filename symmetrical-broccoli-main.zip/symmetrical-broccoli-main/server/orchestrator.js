import { agents as agentDefs } from './data/agents.js';
import { scenarios } from './data/scenarios.js';

const realismGuidance = mode => {
  if (mode === 'static') {
    return 'Maintain steady pacing and concise answers. Avoid long tangents.';
  }
  if (mode === 'dynamic') {
    return 'Allow more natural flow and longer thoughts, but stay relevant.';
  }
  return 'Adaptive pacing: be concise early, expand only when needed, and wrap succinctly.';
};

const buildSystemPrompt = (agent, scenario, realismMode, timeNote) =>
  [
    'You are part of a round-table council with multiple agents and a human moderator.',
    'Stay in your persona and avoid repeating other agents. Keep responses crisp, concrete, and actionable.',
    'If you need clarification, ask one targeted question.',
    'Scenario: ' + scenario.title,
    scenario.prompt,
    'Persona: ' + agent.personality,
    'Pacing: ' + realismGuidance(realismMode),
    timeNote ? 'Chair note: ' + timeNote : null
  ].filter(Boolean).join('\n');

const normalizeHistory = history =>
  history
    .filter(msg => msg && msg.content)
    .map(msg => {
      if (msg.role === 'agent') {
        return { role: 'assistant', content: msg.content };
      }
      if (msg.role === 'system') {
        return { role: 'system', content: msg.content };
      }
      return { role: 'user', content: msg.content };
    });

const buildRoundInstruction = (roundIndex, totalRounds, mode) => {
  if (mode === 'debate') {
    if (roundIndex === 1) {
      return 'Round 1: State your position clearly, with assumptions and a proposed path.';
    }
    if (roundIndex < totalRounds) {
      return 'Round ' + roundIndex + ': Rebut other agents, strengthen your case, and update your recommendation.';
    }
    return 'Final Round: Deliver your strongest, concise recommendation and 1-2 next actions.';
  }
  return 'Provide a concise, helpful response aligned with your persona.';
};

const formatTranscript = roundOutputs =>
  roundOutputs
    .map(output => output.name + ': ' + output.content)
    .join('\n');

export const runRoundTable = async ({
  scenarioId,
  agentIds,
  history,
  modelMapping,
  providers,
  mode = 'roundtable',
  rounds = 3,
  realismMode = 'adaptive',
  timeRemainingSeconds = null
}) => {
  const scenario = scenarios.find(s => s.id === scenarioId) || scenarios[0];
  const selectedAgents = agentDefs.filter(agent => agentIds.includes(agent.id));

  const baseHistory = normalizeHistory(history);
  const minRounds = mode === 'debate' ? 2 : 1;
  const totalRounds = Math.max(minRounds, Math.min(4, Number(rounds) || 1));
  const debateRounds = mode === 'debate' ? totalRounds : 1;
  const roundTranscripts = [];
  let lastRoundResponses = [];

  for (let roundIndex = 1; roundIndex <= debateRounds; roundIndex += 1) {
    const roundResponses = [];
    const roundNote = roundTranscripts.length ? roundTranscripts[roundTranscripts.length - 1] : '';
    const timeNote =
      typeof timeRemainingSeconds === 'number' && timeRemainingSeconds < 90
        ? 'We are nearing session end; wrap in 2-3 crisp points.'
        : null;

    for (const agent of selectedAgents) {
      const mapping = modelMapping?.[agent.id] || agent.defaults;
      const provider = mapping?.provider || 'ollama';
      const model = mapping?.model;

      if (!model) {
        roundResponses.push({
          agentId: agent.id,
          name: agent.name,
          content: 'No model configured for this agent. Assign a model in Model Control.'
        });
        continue;
      }

      const messages = [
        {
          role: 'system',
          content:
            buildSystemPrompt(agent, scenario, realismMode, timeNote) +
            '\n' +
            buildRoundInstruction(roundIndex, debateRounds, mode)
        },
        ...baseHistory
      ];

      if (roundNote) {
        messages.push({
          role: 'system',
          content: 'Round transcript so far:\n' + roundNote
        });
      }

      try {
        let content = '';
        if (provider === 'ollama') {
          content = await providers.ollama({ model, messages });
        } else if (provider === 'openai' || provider === 'openrouter') {
          content = await providers.openai({ model, messages });
        } else if (provider === 'anthropic') {
          content = await providers.anthropic({ model, messages });
        } else if (provider === 'gemini') {
          content = await providers.gemini({ model, messages });
        } else if (provider === 'moonshot') {
          content = await providers.moonshot({ model, messages });
        } else {
          content = 'Unsupported provider: ' + provider;
        }

        roundResponses.push({
          agentId: agent.id,
          name: agent.name,
          content: content || 'No response returned.'
        });
      } catch (error) {
        roundResponses.push({
          agentId: agent.id,
          name: agent.name,
          content: 'Error: ' + error.message
        });
      }
    }

    roundTranscripts.push(formatTranscript(roundResponses));
    lastRoundResponses = roundResponses;
  }

  return {
    responses: lastRoundResponses.map(entry => ({
      agentId: entry.agentId,
      content: entry.content
    })),
    transcript: roundTranscripts.join('\n\n')
  };
};
