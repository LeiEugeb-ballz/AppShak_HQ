import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { v4 as uuid } from 'uuid';
import path from 'path';
import { fileURLToPath } from 'url';
import { listOllamaModels, ollamaChat } from './providers/ollama.js';
import { openaiChat } from './providers/openai.js';
import { anthropicChat } from './providers/anthropic.js';
import { geminiChat } from './providers/gemini.js';
import { moonshotChat } from './providers/moonshot.js';
import { runRoundTable } from './orchestrator.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 5055;
const tokens = new Map();
const sessions = new Map();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(express.json({ limit: '2mb' }));

const getProviderSettings = req => ({
  ollamaHost: process.env.OLLAMA_HOST || 'http://localhost:11434',
  openaiBaseUrl: req.headers['x-openai-baseurl'] || process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1',
  openaiKey: req.headers['x-openai-key'] || process.env.OPENAI_API_KEY || '',
  openrouterAppUrl: process.env.OPENROUTER_APP_URL || '',
  openrouterAppName: process.env.OPENROUTER_APP_NAME || '',
  openrouterClientUrl: req.headers['x-openrouter-app-url'] || '',
  openrouterClientName: req.headers['x-openrouter-app-name'] || '',
  openrouterKey: req.headers['x-openrouter-key'] || '',
  openrouterFreeModel: process.env.OPENROUTER_FREE_MODEL || 'openrouter/free',
  anthropicBaseUrl: req.headers['x-anthropic-baseurl'] || process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com',
  anthropicKey: req.headers['x-anthropic-key'] || process.env.ANTHROPIC_API_KEY || '',
  geminiBaseUrl:
    req.headers['x-gemini-baseurl'] || process.env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta',
  geminiKey: req.headers['x-gemini-key'] || process.env.GEMINI_API_KEY || '',
  moonshotBaseUrl: req.headers['x-moonshot-baseurl'] || process.env.MOONSHOT_BASE_URL || 'https://api.moonshot.ai/v1',
  moonshotKey: req.headers['x-moonshot-key'] || process.env.MOONSHOT_API_KEY || ''
});

const requireAuth = (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.replace('Bearer ', '');
  if (!token || !tokens.has(token)) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  req.user = tokens.get(token);
  next();
};

app.get('/api/health', (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const required = process.env.APP_SHAK_ADMIN_PASSWORD;
  if (required && required !== password) {
    return res.status(403).json({ error: 'Invalid password' });
  }
  const token = uuid();
  tokens.set(token, { username: username || 'Commander', createdAt: Date.now() });
  res.json({ token, username: username || 'Commander' });
});

app.get('/api/ollama/models', requireAuth, async (req, res) => {
  const { ollamaHost } = getProviderSettings(req);
  try {
    const models = await listOllamaModels(ollamaHost);
    res.json({ models });
  } catch (error) {
    res.status(200).json({ models: [], warning: error.message });
  }
});

app.get('/api/openrouter/models', requireAuth, async (req, res) => {
  const { openrouterKey, openaiKey } = getProviderSettings(req);
  const baseUrl = req.headers['x-openrouter-baseurl'] || 'https://openrouter.ai/api/v1';
  const apiKey = openrouterKey || openaiKey || process.env.OPENROUTER_API_KEY || '';
  if (!apiKey) {
    return res.status(400).json({ error: 'OpenRouter API key missing.' });
  }
  try {
    const response = await fetch(baseUrl + '/models', {
      headers: {
        Authorization: 'Bearer ' + apiKey
      }
    });
    if (!response.ok) {
      const text = await response.text().catch(() => '');
      return res.status(response.status).json({ error: text || 'Failed to fetch models.' });
    }
    const payload = await response.json();
    res.json(payload);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/session/start', requireAuth, (req, res) => {
  const { scenarioId, agents, modelMapping, mode, rounds, realismMode } = req.body || {};
  const id = uuid();
  sessions.set(id, {
    id,
    scenarioId,
    agents,
    modelMapping: modelMapping || {},
    mode: mode || 'roundtable',
    rounds: rounds || 3,
    realismMode: realismMode || 'adaptive',
    startedAt: Date.now(),
    maxDurationSeconds: 500,
    createdAt: Date.now()
  });
  res.json({ sessionId: id });
});

app.post('/api/session/step', requireAuth, async (req, res) => {
  const { sessionId, history, modelMapping, mode, rounds, realismMode } = req.body || {};
  const session = sessions.get(sessionId);
  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }
  const elapsedSeconds = Math.floor((Date.now() - session.startedAt) / 1000);
  const remainingSeconds = session.maxDurationSeconds - elapsedSeconds;
  if (remainingSeconds <= 0) {
    return res.json({
      ended: true,
      notice: 'Session adjourned. 500-second cap reached.'
    });
  }

  const providerSettings = getProviderSettings(req);
  const fallbackModelMapping = {};
  if (!modelMapping || Object.keys(modelMapping).length === 0) {
    for (const agentId of session.agents || []) {
      fallbackModelMapping[agentId] = {
        provider: 'openrouter',
        model: providerSettings.openrouterFreeModel
      };
    }
  }
  const effectiveMapping =
    !modelMapping || Object.keys(modelMapping).length === 0
      ? fallbackModelMapping
      : modelMapping || session.modelMapping;
  const providers = {
    ollama: ({ model, messages }) =>
      ollamaChat({ host: providerSettings.ollamaHost, model, messages, temperature: 0.6 }),
    openai: ({ model, messages }) =>
      openaiChat({
        baseUrl: providerSettings.openaiBaseUrl,
        apiKey: providerSettings.openaiKey,
        model,
        messages,
        temperature: 0.7,
        timeoutMs: 30000,
        extraHeaders: {
          ...(providerSettings.openaiBaseUrl.includes('openrouter.ai') &&
          (providerSettings.openrouterAppUrl || providerSettings.openrouterClientUrl)
            ? { 'HTTP-Referer': providerSettings.openrouterClientUrl || providerSettings.openrouterAppUrl }
            : {}),
          ...(providerSettings.openaiBaseUrl.includes('openrouter.ai') &&
          (providerSettings.openrouterAppName || providerSettings.openrouterClientName)
            ? { 'X-Title': providerSettings.openrouterClientName || providerSettings.openrouterAppName }
            : {})
        }
      }),
    anthropic: ({ model, messages }) =>
      anthropicChat({
        baseUrl: providerSettings.anthropicBaseUrl,
        apiKey: providerSettings.anthropicKey,
        model,
        messages,
        temperature: 0.7
      }),
    gemini: ({ model, messages }) =>
      geminiChat({
        baseUrl: providerSettings.geminiBaseUrl,
        apiKey: providerSettings.geminiKey,
        model,
        messages,
        temperature: 0.7
      }),
    moonshot: ({ model, messages }) =>
      moonshotChat({
        baseUrl: providerSettings.moonshotBaseUrl,
        apiKey: providerSettings.moonshotKey,
        model,
        messages,
        temperature: 0.7
      })
  };

  const resolveSummaryProvider = mapping => {
    const preferred = mapping?.atlas || null;
    if (preferred?.provider) return preferred;
    const first = Object.values(mapping || {})[0];
    return first || { provider: 'ollama', model: 'llama3.1:8b' };
  };

  try {
    const result = await runRoundTable({
      scenarioId: session.scenarioId,
      agentIds: session.agents,
      history: history || [],
      modelMapping: effectiveMapping,
      providers,
      mode: mode || session.mode,
      rounds: rounds || session.rounds,
      realismMode: realismMode || session.realismMode,
      timeRemainingSeconds: remainingSeconds
    });

    const summaryConfig = resolveSummaryProvider(effectiveMapping);
    let summary = '';
    if (result.transcript) {
      const summaryPrompt = [
        'You are the orchestrator summarizing a multi-agent roundtable.',
        'Provide a crisp executive summary with decisions, risks, and next steps.',
        'Keep it under 8 bullet points and avoid repetition.',
        'Transcript:',
        result.transcript
      ].join('\n');

      if (summaryConfig.provider === 'openai') {
        summary = await providers.openai({
          model: summaryConfig.model || 'gpt-4o-mini',
          messages: [
            { role: 'system', content: summaryPrompt },
            { role: 'user', content: 'Summarize now.' }
          ]
        });
      } else if (summaryConfig.provider === 'anthropic') {
        summary = await providers.anthropic({
          model: summaryConfig.model || 'claude-3-haiku-20240307',
          messages: [
            { role: 'system', content: summaryPrompt },
            { role: 'user', content: 'Summarize now.' }
          ]
        });
      } else {
        summary = await providers.ollama({
          model: summaryConfig.model || 'llama3.1:8b',
          messages: [
            { role: 'system', content: summaryPrompt },
            { role: 'user', content: 'Summarize now.' }
          ]
        });
      }
    }

    res.json({
      responses: result.responses,
      summary,
      remainingSeconds
    });
  } catch (error) {
    console.error('session/step error', {
      message: error.message,
      provider: effectiveMapping?.atlas?.provider,
      model: effectiveMapping?.atlas?.model
    });
    res.status(500).json({ error: error.message });
  }
});

const distPath = path.join(__dirname, '..', 'dist');
app.use(express.static(distPath));

app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(port, () => {
  console.log('App-Shak server running on http://localhost:' + port);
});
