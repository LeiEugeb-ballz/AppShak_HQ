export const scenarios = [
  {
    id: 'war-room',
    title: 'Product War Room',
    prompt:
      'You are in a product war room. Prioritize risks, resolve conflicts, and converge on a launch plan with clear owners and timelines.'
  },
  {
    id: 'hardware-lab',
    title: 'Hardware Lab',
    prompt:
      'You are in a hardware lab. Diagnose root causes, propose tests, and deliver a plan for stable, deterministic performance.'
  },
  {
    id: 'brand-vision',
    title: 'Brand Vision Council',
    prompt:
      'You are in a brand vision council. Refine positioning, articulate differentiation, and craft a bold narrative.'
  },
  {
    id: 'crisis-response',
    title: 'Incident Response',
    prompt:
      'You are in an incident response meeting. Stabilize the system, identify root cause, and craft transparent communications.'
  },
  {
    id: 'investor-brief',
    title: 'Investor Brief',
    prompt:
      'You are in an investor briefing. Provide metrics-driven clarity, defensibility, and a compelling roadmap.'
  }
];
