const toAnthropicMessages = messages => {
  const systemParts = [];
  const anthropicMessages = [];

  messages.forEach(msg => {
    if (msg.role === 'system') {
      systemParts.push(msg.content);
    } else if (msg.role === 'user' || msg.role === 'assistant') {
      anthropicMessages.push({ role: msg.role, content: msg.content });
    }
  });

  return {
    system: systemParts.join('\n\n'),
    messages: anthropicMessages
  };
};

export const anthropicChat = async ({ baseUrl, apiKey, model, messages, temperature }) => {
  if (!apiKey) throw new Error('Anthropic API key missing');
  const formatted = toAnthropicMessages(messages);
  const res = await fetch(baseUrl + '/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model,
      max_tokens: 800,
      temperature: temperature ?? 0.7,
      system: formatted.system,
      messages: formatted.messages
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Anthropic request failed');
  }

  const data = await res.json();
  return data.content?.[0]?.text?.trim() || '';
};
