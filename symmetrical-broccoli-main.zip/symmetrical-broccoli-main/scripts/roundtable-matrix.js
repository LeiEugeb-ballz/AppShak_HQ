import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { agents as agentDefs } from '../server/data/agents.js';
import { scenarios } from '../server/data/scenarios.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const API_KEY = process.env.OPENAI_API_KEY;
const BASE_URL = process.env.OPENAI_BASE_URL || 'https://openrouter.ai/api/v1';
const MAX_TURNS = Number(process.env.MAX_TURNS || 10);
const MAX_SECONDS = Number(process.env.MAX_SECONDS || 300);
const SCENARIO_ID = process.env.SCENARIO_ID || scenarios[0]?.id;

if (!API_KEY) {
  throw new Error('OPENAI_API_KEY is required for OpenRouter tests.');
}

const scenario = scenarios.find(item => item.id === SCENARIO_ID) || scenarios[0];
if (!scenario) {
  throw new Error('No scenarios found.');
}

const combinations = (list, minSize, maxSize) => {
  const result = [];
  const helper = (start, combo) => {
    if (combo.length >= minSize && combo.length <= maxSize) {
      result.push([...combo]);
    }
    if (combo.length === maxSize) return;
    for (let i = start; i < list.length; i += 1) {
      combo.push(list[i]);
      helper(i + 1, combo);
      combo.pop();
    }
  };
  helper(0, []);
  return result;
};

const token = text =>
  text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);

const similarity = (a, b) => {
  if (!a || !b) return 0;
  const aTokens = new Set(token(a));
  const bTokens = new Set(token(b));
  if (aTokens.size === 0 || bTokens.size === 0) return 0;
  let intersect = 0;
  for (const t of aTokens) {
    if (bTokens.has(t)) intersect += 1;
  }
  return intersect / Math.max(aTokens.size, bTokens.size);
};

const personaKeywords = personality => {
  const words = token(personality).filter(word => word.length > 4);
  const seen = new Set();
  const keywords = [];
  for (const word of words) {
    if (seen.has(word)) continue;
    seen.add(word);
    keywords.push(word);
    if (keywords.length >= 6) break;
  }
  return keywords;
};

const buildSystemPrompt = (agent, previousSpeaker) => {
  const personaLine = `Persona: ${agent.personality}`;
  const scenarioLine = `Scenario: ${scenario.title}\n${scenario.prompt}`;
  const previousLine = previousSpeaker
    ? `Previous speaker: ${previousSpeaker.name} said: ${previousSpeaker.content}`
    : 'Previous speaker: none yet.';
  return [
    'You are part of a round-robin roundtable. Stay in persona and respond concisely.',
    scenarioLine,
    personaLine,
    previousLine,
    'Explicitly reference the previous speaker when possible.'
  ].join('\n');
};

const fetchOpenRouterModels = async () => {
  const response = await fetch(`${BASE_URL}/models`, {
    headers: { Authorization: `Bearer ${API_KEY}` }
  });
  if (!response.ok) {
    throw new Error('Failed to fetch OpenRouter models: ' + response.status);
  }
  const payload = await response.json();
  return payload.data || [];
};

const pricingMap = models => {
  const map = new Map();
  for (const model of models) {
    if (model?.id) map.set(model.id, model.pricing || {});
  }
  return map;
};

const costEstimate = (pricing, usage) => {
  if (!pricing || !usage) return null;
  const promptRate = Number(pricing.prompt || 0);
  const completionRate = Number(pricing.completion || 0);
  if (!promptRate && !completionRate) return null;
  const promptCost = (usage.prompt_tokens || 0) * promptRate;
  const completionCost = (usage.completion_tokens || 0) * completionRate;
  return promptCost + completionCost;
};

const chatCompletion = async ({ model, messages }) => {
  const start = Date.now();
  const response = await fetch(`${BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${API_KEY}`,
      'HTTP-Referer': 'https://appshak.local/test',
      'X-Title': 'AppShak Roundtable Bench'
    },
    body: JSON.stringify({ model, messages, temperature: 0.7 })
  });

  const ttfbStart = Date.now();
  let ttfbMs = null;
  if (response.body) {
    const reader = response.body.getReader();
    const firstChunk = await reader.read();
    ttfbMs = Date.now() - start;
    const restChunks = [];
    if (!firstChunk.done) restChunks.push(firstChunk.value);
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      restChunks.push(chunk.value);
    }
    const merged = Buffer.concat(restChunks.map(chunk => Buffer.from(chunk)));
    const text = merged.toString('utf8');
    return { raw: JSON.parse(text), ttfbMs, elapsedMs: Date.now() - start };
  }

  const data = await response.json();
  return { raw: data, ttfbMs: Date.now() - ttfbStart, elapsedMs: Date.now() - start };
};

const evaluateContext = (responseText, previousSpeaker) => {
  if (!previousSpeaker) return true;
  const lowered = responseText.toLowerCase();
  return lowered.includes(previousSpeaker.name.toLowerCase()) || lowered.includes('previous') || lowered.includes('earlier');
};

const evaluatePersona = (responseText, agent) => {
  const keywords = personaKeywords(agent.personality);
  const lowered = responseText.toLowerCase();
  return keywords.some(word => lowered.includes(word));
};

const detectLoop = (responseText, lastResponse) => similarity(responseText, lastResponse) > 0.9;

const resolutionStatus = responses => {
  const combined = responses.join(' ').toLowerCase();
  if (combined.includes('deadlock') || combined.includes('stalemate')) return 'deadlock';
  if (combined.includes('consensus') || combined.includes('we agree') || combined.includes('aligned')) return 'consensus';
  return 'unclear';
};

const runCombination = async ({ comboAgents, pricing }) => {
  const history = [{ role: 'user', content: scenario.prompt }];
  const metrics = [];
  const lastResponses = new Map();
  const allResponses = [];
  const startedAt = Date.now();
  let turn = 0;

  while (turn < MAX_TURNS && (Date.now() - startedAt) / 1000 < MAX_SECONDS) {
    const agent = comboAgents[turn % comboAgents.length];
    const previousSpeaker = metrics.length
      ? { name: metrics[metrics.length - 1].agentName, content: metrics[metrics.length - 1].responseText }
      : null;
    const messages = [
      { role: 'system', content: buildSystemPrompt(agent, previousSpeaker) },
      ...history
    ];

    const result = await chatCompletion({ model: agent.defaults.model, messages });
    const modelId = result.raw?.model || result.raw?.id || agent.defaults.model;
    const usage = result.raw?.usage || null;
    const responseText = result.raw?.choices?.[0]?.message?.content?.trim() || '';
    const looped = detectLoop(responseText, lastResponses.get(agent.id) || '');
    const contextPass = evaluateContext(responseText, previousSpeaker);
    const personaPass = evaluatePersona(responseText, agent);
    const price = costEstimate(pricing.get(modelId), usage);

    history.push({ role: 'assistant', content: responseText });
    lastResponses.set(agent.id, responseText);
    allResponses.push(responseText);

    metrics.push({
      agentId: agent.id,
      agentName: agent.name,
      modelRequested: agent.defaults.model,
      modelRouted: modelId,
      ttfbMs: result.ttfbMs,
      elapsedMs: result.elapsedMs,
      promptTokens: usage?.prompt_tokens || null,
      completionTokens: usage?.completion_tokens || null,
      costEstimate: price,
      contextPass,
      personaPass,
      looped,
      responseText
    });

    turn += 1;
  }

  const resolution = resolutionStatus(allResponses);
  return { metrics, resolution };
};

const summarizeCombination = ({ comboKey, metrics, resolution }) => {
  const avgTtfb = metrics.reduce((sum, item) => sum + (item.ttfbMs || 0), 0) / Math.max(metrics.length, 1);
  const avgElapsed = metrics.reduce((sum, item) => sum + (item.elapsedMs || 0), 0) / Math.max(metrics.length, 1);
  const promptTokens = metrics.reduce((sum, item) => sum + (item.promptTokens || 0), 0);
  const completionTokens = metrics.reduce((sum, item) => sum + (item.completionTokens || 0), 0);
  const totalCost = metrics.reduce((sum, item) => sum + (item.costEstimate || 0), 0);
  const contextPassRate = metrics.filter(item => item.contextPass).length / Math.max(metrics.length, 1);
  const personaPassRate = metrics.filter(item => item.personaPass).length / Math.max(metrics.length, 1);
  const loops = metrics.filter(item => item.looped).length;

  return {
    comboKey,
    turns: metrics.length,
    avgTtfbMs: Math.round(avgTtfb),
    avgElapsedMs: Math.round(avgElapsed),
    promptTokens,
    completionTokens,
    totalTokens: promptTokens + completionTokens,
    totalCost,
    contextPassRate,
    personaPassRate,
    loops,
    resolution
  };
};

const writeReports = async ({ summary, details }) => {
  const outputDir = path.join(__dirname, '..', 'reports');
  await fs.mkdir(outputDir, { recursive: true });
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const summaryPath = path.join(outputDir, `roundtable-summary-${timestamp}.json`);
  const detailPath = path.join(outputDir, `roundtable-details-${timestamp}.json`);
  const csvPath = path.join(outputDir, `roundtable-summary-${timestamp}.csv`);

  const csvHeaders = [
    'combo',
    'turns',
    'avg_ttfb_ms',
    'avg_elapsed_ms',
    'prompt_tokens',
    'completion_tokens',
    'total_tokens',
    'total_cost',
    'context_pass_rate',
    'persona_pass_rate',
    'loops',
    'resolution'
  ];

  const csvRows = summary.map(item =>
    [
      item.comboKey,
      item.turns,
      item.avgTtfbMs,
      item.avgElapsedMs,
      item.promptTokens,
      item.completionTokens,
      item.totalTokens,
      item.totalCost?.toFixed(6) ?? '',
      item.contextPassRate.toFixed(2),
      item.personaPassRate.toFixed(2),
      item.loops,
      item.resolution
    ].join(',')
  );

  await fs.writeFile(summaryPath, JSON.stringify(summary, null, 2));
  await fs.writeFile(detailPath, JSON.stringify(details, null, 2));
  await fs.writeFile(csvPath, [csvHeaders.join(','), ...csvRows].join('\n'));

  return { summaryPath, detailPath, csvPath };
};

const main = async () => {
  const models = await fetchOpenRouterModels();
  const pricing = pricingMap(models);
  const agentCombos = combinations(agentDefs, 2, Math.min(5, agentDefs.length));
  const summary = [];
  const details = [];

  for (const combo of agentCombos) {
    const comboKey = combo.map(agent => agent.name).join(' + ');
    const { metrics, resolution } = await runCombination({ comboAgents: combo, pricing });
    const summarized = summarizeCombination({ comboKey, metrics, resolution });
    summary.push(summarized);
    details.push({ comboKey, metrics, resolution });
    console.log(`Finished ${comboKey} (${metrics.length} turns)`);
  }

  const reportPaths = await writeReports({ summary, details });
  console.log('Reports saved:', reportPaths);
};

await main();
